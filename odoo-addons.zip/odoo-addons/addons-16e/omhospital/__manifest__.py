{
    "name": "onhospital",
    "category": "Services",
    "depends": ["mail"],
    "data": [
        "data/review_patient.xml",
        "views/menu.xml",
        "views/doctors.xml",
        "views/admin.xml",
        "views/patients.xml",
        "views/female_doc.xml",
        "views/appointment.xml",
        "report/patient_card.xml",
        "report/report_status.xml",
        "report/doctor_report.xml",
        "report/reports.xml",

    
    ],
    "images": ["static/description/omhospital.png"],
    'installable': True,
    'application': True
}
