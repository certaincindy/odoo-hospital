from odoo import fields, models

class Doctor(models.Model):
    _name = "hospital.doctor"
    _description = "Doctors"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Name", required=True, tracking=True)
    age = fields.Integer(string="Age", required=True)
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')], string="Gender")
    Department = fields.Selection([('general', 'General'), ('ortho', 'Ortho'), ('eye', 'Eye')], string="Dept")
    Salary = fields.Integer(string="Salary", required=True, tracking=True)
    active = fields.Boolean(string="Active", default=True)

    # Add the priority field
    priority = fields.Selection(
        [('0', 'Low'), ('1', 'Normal'), ('2', 'High')],
        string="Priority",
        default='1',
        tracking=True
    )

    def test_button(self):
        for rec in self:
            rec.name = "Button Pressed"

    def increase_salary(self):
        for rec in self:
            rec.Salary += 1000