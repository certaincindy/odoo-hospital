from odoo import models, fields, api, _


class Appointment(models.Model):
    _name = "hospital.appointment"
    # Form inheritance. Built in. Not from scracth.
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Appointment Records"

    name = fields.Char(string="Appointment Ref.", tracking=True, required=True)
    date = fields.Date(string="Appointment Date")
    reason = fields.Text(string="Appointment Reason")

    patient_id = fields.Many2one("hospital.patient", string="Patient", required=True)
    # using the related variable and then pulling the required variable.
    patient_age = fields.Integer(string="Patient Age", related="patient_id.age")
    patient_gender = fields.Selection(
        string="Patient Gender", related="patient_id.gender", readonly=True
    )
    prescription = fields.Html(string="Prescription")


    @api.onchange("patient_id")
    def onchange_patient_id(self):
        self.name = self.patient_id.name
        self.patient_age = self.patient_id.age
        self.patient_gender = self.patient_id.gender


    @api.model
    def _cron_auto_create_followups(self):
        appointments = self.search([])
        for appointment in appointments:
            followup_date = fields.Date.add(appointment.date, days=7)
            self.create(
                {
                    "name": f"Follow-up for {appointment.name}",
                    "date": followup_date,
                    "reason": "Follow-up Appointment",
                    "patient_id": appointment.patient_id.id,
                }
            )
        return True