#Whenever you create a new model, you need to import it here so that Odoo can recognize and load it properly.
from . import patient,doctors,admin,appointment