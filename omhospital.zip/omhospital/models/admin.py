from odoo import models,fields

class Admin(models.Model):

    _name="hospital.admin"
    _description="Admins of the hospital"

    name=fields.Char(string="Admin",required=True)
    department=fields.Selection([('IT','it'),('Health','health')],string="Department",required=True)
    