from ast import mod
from odoo import models, fields, api, _
from datetime import date


class Patient(models.Model):
    _name = "hospital.patient"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Patient Records."

    name = fields.Char(string="Name", required=True)
    dob = fields.Date(string="Date of Birth", required=True)
    age = fields.Integer(string="Age", compute="_compute_age", store=True)
    gender = fields.Selection(
        [("male", "Male"), ("female", "Female"), ("other", "Other")], string="Gender"
    )
    is_child = fields.Boolean(string="Is Child?")
    Desc = fields.Text(string="Description", required=True)
    reviewed = fields.Boolean(string="Reviewed", default=False)

    cured = fields.Boolean(string="Cured", default=False, required=True)
    image = fields.Image(string="Patient Image")
    priority = fields.Selection([("1", "Low"), ("2", "Emergency"), ("3", "ICU")])
    status = fields.Selection(
        [
            ("admitted", "Admitted"),
            ("discharged", "Discharged"),
            ("cancel", "Cancelled"),
        ],
        string="Status",
        default="admitted",
    )
    appointment_ids = fields.One2many(
        "hospital.appointment", "patient_id", string="Appointments"
    )

    @api.depends("dob")
    def _compute_age(self):

        for rec in self:
            if rec.dob:
                today = date.today()
                rec.age = today.year - rec.dob.year
                if (today.month, today.day) < (rec.dob.month, rec.dob.day):
                    rec.age -= 1
            else:
                rec.age = 0
