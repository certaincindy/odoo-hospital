from odoo import models, fields, api, _


class Appointment(models.Model):
    _name = "hospital.appointment"
    # Form inheritance. Built in. Not from scracth.
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _description = "Appointment Records"

    name = fields.Char(string="Appointment Ref.", tracking=True, required=True)
    date = fields.Datetime(string="Appointment Date")
    reason = fields.Text(string="Appointment Reason")

    patient_id = fields.Many2one("hospital.patient", string="Patient", required=True)
    # using the related variable and then pulling the required variable.
    patient_age = fields.Integer(string="Patient Age", related="patient_id.age")
    patient_gender = fields.Selection(string="Patient Gender", related="patient_id.gender", readonly=True)
    prescription = fields.Html(string="Prescription")
